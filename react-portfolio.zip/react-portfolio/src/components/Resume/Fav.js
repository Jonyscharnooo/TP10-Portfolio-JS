import React from "react";
import { Container, Row } from "react-bootstrap";
import FavCard from "./FavCard";

function Fav({ favorites, setFavorites }) {
  const handleRemoveFromFavorites = (projectToRemove) => {
    const updatedFavorites = favorites.filter((project) => project !== projectToRemove);
    setFavorites(updatedFavorites);
  };

  return (
    <div>
      <Container fluid className="resume-section">
        <Row className="resume">
          {favorites && favorites.length > 0 ? (
            favorites.map((favorite, index) => (
              <div key={index} className="fav-project">
                <FavCard
                  project={favorite}
                  onRemoveFromFavorites={() => handleRemoveFromFavorites(favorite)}
                />
              </div>
            ))
          ) : (
            <p>No hay proyectos favoritos</p>
          )}
        </Row>
      </Container>
    </div>
  );
}

export default Fav;