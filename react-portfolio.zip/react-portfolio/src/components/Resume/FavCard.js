// En FavCard.js
import React from "react";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import { BiLinkExternal } from "react-icons/bi";

function FavCard({ project }) {
  return (
    <Card className="project-card-view">
      {project.image && <Card.Img variant="top" src={project.image} alt="card-img" />}
      <Card.Body>
        <Card.Title style={{ fontWeight: "bold" }}>{project.title}</Card.Title>
        <Card.Text className="purple">Tecnologias: {project.technologyUsed}</Card.Text>
        <Card.Text style={{ textAlign: "justify" }}>
          {project.description}
        </Card.Text>
        {project.link && (
          <Button variant="primary" href={project.link} target="_blank" className="download-button">
            <BiLinkExternal /> &nbsp; View Project
          </Button>
        )}
      </Card.Body>
    </Card>
  );
}

export default FavCard;