// En Projects.js
import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";
import { PROJECTS } from "../../Constants";

function Projects({ favorites, setFavorites }) {
  const handleAddToFavorites = (project) => {
    if (!favorites.some((fav) => fav.name === project.name)) {
      setFavorites([...favorites, project]);
    } else {
      alert("¡Este proyecto ya está en tus favoritos!");
    }
  };

  return (
    <Container fluid className="project-section">
      <Container>
        <h1 className="project-heading">
          Trabajos <strong className="purple">recientes </strong>
        </h1>
        <p style={{ color: "grey" }}>
          Estos son algunos de los proyectos que tengo en mi github.
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          {PROJECTS.map((project, index) => (
            <Col md={4} className="project-card" key={index}>
              <ProjectCard
                imgPath={project.image}
                technologyUsed={project.technologyUsed}
                isBlog={false}
                title={project.name}
                description={project.description}
                link={project.url}
                onAddToFavorites={() => handleAddToFavorites(project)}
              />
            </Col>
          ))}
        </Row>
      </Container>
    </Container>
  );
}

export default Projects;