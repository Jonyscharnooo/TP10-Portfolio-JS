import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";
function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
            Hola soy <span className="purple">Jonathan Scharnopolsky </span>
            from <span className="purple"> Lucknow, India.</span>
            <br />
            Estudiante de ORT Almagro que le gusta programar.
            <br />
            En mi tiempo libre me dedico a jugar a juegos en la pc y descubrir las nuevas tecnologias que hay en el mundo.
            <br />
            Ademas, en mi tiempo libre suelo hacer:
          </p>
          <ul>
            <li className="about-activity">
              <ImPointRight /> Panqueques con forma del Nashor
            </li>
            <li className="about-activity">
              <ImPointRight /> Estudio las ultimas builds de mis campeones
            </li>
            <li className="about-activity">
              <ImPointRight /> Me aprendo los humos del CS
            </li>
            <li className="about-activity">
              <ImPointRight /> AIMBOTZ
            </li>
          </ul>
        </blockquote>
      </Card.Body>
    </Card>
  );
}

export default AboutCard;
