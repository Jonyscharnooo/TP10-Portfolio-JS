import AUTOMATION from "./Assets/Projects/3automation.jpg";
import COAST from "./Assets/Projects/coast.jpg";
import DROPSHIP from "./Assets/Projects/dropship.jpg";
import GOOD_FOOD_DISCOUNTS from "./Assets/Projects/goodFoodDiscounts.png";
import GUAMEDIA from "./Assets/Projects/guamedia.jpg";
import HSP from "./Assets/Projects/hsp.png";
import COSMOS from "./Assets/Projects/cosmos.jpg";
import TECHSPEC from "./Assets/Projects/techspec.png";
import TRAVELWELL from "./Assets/Projects/travelwell.png";


export const PROJECTS = [
  {
    image: COSMOS,
    name: "Proyecto Final Creando Luz",
    technologyUsed: "C#, HTML, CSS, MVC",
    description: "Una web institucional para la organizacion Creando Luz",
    url: "https://github.com/Jonyscharnooo/TP_CreandoLuz_JS_JC",
  },
  {
    image: TRAVELWELL,
    name: "TP Hardware DAI",
    technologyUsed: "React Native, Javascript",
    description: "TP para la materia DAI 2023 sobre una app para el celular en la que se puede escanear codigos QR, saber el clima y demas funciones del celular.",
    url: "https://github.com/Jonyscharnooo/TPHardware_JS_GP",
  },
  {
    image: COAST,
    name: "Coast",
    technologyUsed: "ReactNative, Javascript, Redux",
    description: "Team collaboration mobile app and online services like slack Message people and groups without sharing phone numbers, communicate with managers and staff all in one place. and discuss or assign tasks to get stuff done",
    url: "https://play.google.com/store/apps/details?id=com.fomo.android.app",
  },
  {
    image: AUTOMATION,
    name: "3automation.com (RPA)",
    technologyUsed: "ReactJs, Typescript, Redux",
    description: "The next-gen Robotic Process Automation (#RPA) platform for retail and telecom domains. The ultimate automation platform for your Shopify, Email, E- commerce shop",
    url: "https://www.3automation.com/",
  },
  {
    image: GUAMEDIA,
    name: "GuaMedia",
    technologyUsed: "ReactNative, Javascript, Redux",
    description: "Social media mobile app similar to Twitter for china. Social networking GUOMEDIA is an all-in-one social networking platform where users can build their own user profiles, create their own posts, Livestream broadcast and follow each other",
    url: "https://play.google.com/store/apps/details?id=com.tiu.guo.media",
  },
  {
    image: TECHSPEC,
    name: "TechSpec",
    technologyUsed: "ReactJs, Typescript, Redux",
    description: "TechSpec is e-commerce web app. User can compare his product and purchange. This had a dashboard web app which had the data of orders placed and type of user.",
    url: "",
  },
  {
    image: HSP,
    name: "HSP (Health Solution Plus)",
    technologyUsed: "ReactJs, Javascript, Redux",
    description: "This is a Healthcare sector project which would be developed as replica of a desktop application. My responsibilities in this project are to develop UI, perform searching of medical codes and categories, addition/updation of codes and categories.",
    url: "",
  },
  {
    image: DROPSHIP,
    name: "DropShip Shopify App",
    technologyUsed: "Shopify, React, typescript, polaris, GraphQL, Nodejs, Koajs",
    description: "It is customized clothes shopify app which fetch order from store and give option to customize product and send detail to store owner. Also maintain tracking etc of product.",
    url: "",
  },
  {
    image: GOOD_FOOD_DISCOUNTS,
    name: "GoodFoodDiscounts",
    technologyUsed: "ReactNative, Javascript, Redux",
    description: "Good food discouts app is similar like swiggy. Food and hotel can be searched and can be order. Even has facility to add coupan. You can add food in favourite list.",
    url: "",
  },
];

export const SKILLS = [
  { name: "ReactJs", initialRating: 1 },
  { name: "React-Native", initialRating: 2 },
  { name: "JavaScript", initialRating: 4 },
  { name: "C#", initialRating: 5 },
  { name: "MS SQL", initialRating: 3 },
  { name: "Nodejs", initialRating: 3 },
  { name: "Html", initialRating: 4 },
  { name: "CSS", initialRating: 4 },
  { name: "Yarn", initialRating: 3 },
  { name: "Git", initialRating: 1 },
];

export const TOOLS = ["Visual Studio Code", "Git", "React", "Npm", "React Native", "Visual Studio", "Microsoft SQL Server", "Windows", "Postman"]
